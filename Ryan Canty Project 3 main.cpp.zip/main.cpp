// Project 3

// Author: Ryan Canty

// Date: 9/24/15

// Course: CSC1610

// Description: This file prompts the user for 3 doubles and then performs the
// Quadratic formula with them, computing both positive and negative roots.

// Input: Three user-defined doubles collected from the standard
// input stream (keyboard)

// Output: Positive and negative roots of the quadratic formula.

#include <cstdlib>
#include <iostream>
#include <string>
#include <cmath>
#include <iomanip>

using namespace std;

void quadEquation( double, double, double );

/*
 * 
 */
int main() {

    double a;
    double b;
    double c;
    cout << "Please enter 3 numbers to perform the quadratic formula with: ";
    cin >> a >> b >> c;
    quadEquation( a, b, c );
    //cout << a << b << c;
    
    
    return 0;
}

void quadEquation( double a, double b, double c ) 
{
    double quadAnsPos;
    quadAnsPos = (-b + (sqrt((pow(b,2.0)) - (4.0 * a * c)))) / (2.0 * a);
    double quadAnsNeg;
    quadAnsNeg = (-b - (sqrt((pow(b,2.0)) - (4.0 * a * c)))) / (2.0 * a);
    cout << "The positive roots are: " << quadAnsPos << endl;
    cout << "The negative roots are: " << quadAnsNeg << endl;
}